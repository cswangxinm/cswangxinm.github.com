/*
 Author: Yi Zhen
 Email: yzhen@cse.ust.hk and zhenyisx@gmail.com
 Usage:
 ./g++ -o tagicf tagicofi.cpp
 ./tagicf <train file> <test file> <sim file> <DIM> <alpha> <beta> <step>
*/



#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <set>
#include <math.h>
#include <time.h>
#include <float.h>

using namespace std;

const int RATING_NUM = 33492;			//20%
//const int RATING_NUM = 334556;		//100%
//const int RATING_NUM = 267658;		//80%

//const int RATING_NUM = 167474;		//50%
//const int RATING_NUM = 331217;		//99%
//const int TRUST_NUM = 573049;

const int USER_NUM = 757;
const int ITEM_NUM = 9485;

//const short DIM = 10;
//const float alpha = (float)1;
//const float beta = (float)0.5;
//const float step = (float)0.001;

// original data
float*	rates; // starts at rates[0]
int*	mids;
int*	uids;

float**  sims;
float* simvector;

double globalmean;

vector<int>* itemRateVectors;
vector<int>* userRateVectors;

//latent matrix
float ** latentU;
float ** latentV;



// load data
void WaitForEnterKey ()
{
	char ch = '\0';

	cout << "Press ENTER to continue . . . ";
	cout.flush();

	while (!(ch == '\n' || ch == '\r'))
		ch = (char)getchar();

	return;
}


int preload_data(char* srate, char* ssim, float beta)
{
	rates = new float[RATING_NUM]; // starts at rates[1]
	memset(rates,0,sizeof(float)*RATING_NUM);
	mids = new int[RATING_NUM];
	memset(mids,0,sizeof(int)*RATING_NUM);
	uids = new int[RATING_NUM];
	memset(uids,0,sizeof(int)*RATING_NUM);
	globalmean = 0;

	//parents = new int[TRUST_NUM];	// starts at parents[0]
	//memset(parents,0,sizeof(int)*TRUST_NUM);
	//children = new int[TRUST_NUM];
	//memset(children,0,sizeof(int)*TRUST_NUM);
	//sims = new float[TRUST_NUM];
	//memset(sims,0,sizeof(float)*TRUST_NUM);
	sims = new float*[USER_NUM];
	for (int i = 0; i<USER_NUM;i++)
	{
		sims[i] = new float[USER_NUM];
		for (int j = 0;j < USER_NUM;j++)
		{
			sims[i][j] = 0;
		}
	}

	itemRateVectors = new vector<int>[ITEM_NUM];
	userRateVectors = new vector<int>[USER_NUM];

	// handle rate file
	ifstream fin_rate(srate);
	if (fin_rate.fail())
	{
		cout<<"failed to open the file"<<endl;
		return 0;
	}
	else
	{
		int rate_number = 0;
		char buffer_rate[30];
		memset(buffer_rate, 0, 30);
		fin_rate.getline(buffer_rate, 30);
		while (strlen(buffer_rate) > 0)
		{
			//cout<<"Reading Successful"<<endl;
			float input_rate;
			int mid;
			int uid;
			sscanf(buffer_rate, "%d %d %f", &uid, &mid, &input_rate);
			itemRateVectors[mid-1].push_back(rate_number);
			userRateVectors[uid-1].push_back(rate_number);
			rates[rate_number] = static_cast<float>(input_rate);
			uids[rate_number] = uid-1;
			mids[rate_number] = mid-1;
			memset(buffer_rate, 0, 30);
			fin_rate.getline(buffer_rate, 30);
			rate_number++;
			globalmean += (double)input_rate;
		}
		fin_rate.close();
		globalmean /= (double)rate_number;

	}
	cout<<"Global mean:"<<globalmean<<endl;

	// all distract globalmean to get better performance
	for (int k = 0; k < RATING_NUM;k++)
	{
		rates[k] = rates[k] - static_cast<float>(globalmean);
	}

	// handle similarity file
	if (beta>0)
	{
		ifstream fin_trust( ssim );
		if (fin_trust.fail())
		{
			cout<<"failed to open the file"<<endl;
			return 0;
		}
		else
		{
			char buffer_trust[30];
			memset(buffer_trust, 0, 30);
			fin_trust.getline(buffer_trust, 30);
			int trust_number = 0;
			while (strlen(buffer_trust) > 0)
			{
				//cout<<buffer_trust<<endl;
				float input_rate;
				int parent;
				int child;
				sscanf(buffer_trust, "%d %d %f", &parent, &child, &input_rate);
				sims[parent-1][child-1] = static_cast<float>(input_rate);
				//parents[trust_number] = parent - 1;
				//children[trust_number] = child - 1;
				//sims[trust_number] = static_cast<float>(input_rate);
				memset(buffer_trust, 0, 30);
				fin_trust.getline(buffer_trust, 30);
				trust_number++;
			}
			fin_trust.close();

		}

		// sum of similarity of each row
		simvector = new float[USER_NUM];
		for (int i = 0; i < USER_NUM; i++)
		{
			float product = 0;
			for (int j = 0; j < USER_NUM; j++)
			{
				product += sims[i][j];
			}
			simvector[i] = product;
		}
	}

	return 1;

}


void InitializeParameter(int DIM)
{
	// initialize
	srand((unsigned)time( NULL ) );

	// latent U and V
	latentU = new float*[DIM];
	latentV = new float*[DIM];
	for (int i = 0;i<DIM;i++)
	{
		latentU[i] = new float[USER_NUM];
		for (int j = 0;j < USER_NUM;j++)
		{
			//latentU[i][j]=(float)0.1*((float)rand()/(float)RAND_MAX-(float)0.5);
			latentU[i][j]=1*(float)rand()/(float)RAND_MAX;
			//latentU[i][j] = (float)0.1;
		}
		latentV[i] = new float[ITEM_NUM];
		for (int j = 0;j < ITEM_NUM;j++)
		{
			//latentV[i][j]=(float)0.1*((float)rand()/(float)RAND_MAX-(float)0.5);
			latentV[i][j]=1*(float)rand()/(float)RAND_MAX;
			//latentV[i][j] = (float)0.1;
		}
	}

}
double compute_objective(float alpha, float beta, float step, int DIM)
{
	// compute the value of objective function
	float part1=0,part4=0,part5=0,part6=0;
	part1 = 0;
	for (int i = 0;i<RATING_NUM;i++)
	{
		float temp = 0;
		float prod = 0;
		for (int d = 0; d<DIM;d++)
		{
			prod += latentU[d][uids[i]]*latentV[d][mids[i]];
		}
		temp = rates[i]-prod;
		part1 += temp*temp;
	}


	part6 = 0;
	for (int i = 0;i<USER_NUM;i++)
	{
		for (int d = 0;d<DIM;d++)
			part6 += latentU[d][i]*latentU[d][i];
	}
	part6 *= alpha;

	part5 = 0;
	for (int i = 0; i< USER_NUM; i++)
	{
		for (int j = 0; j < USER_NUM; j++)
		{
			float prod = 0;
			float latentu_diter = 0;
			if (sims[i][j] > 0)
			{
				for (int d = 0;d<DIM;d++)
				{
					latentu_diter = latentU[d][j];
					prod+=(latentU[d][i]-latentu_diter)*(latentU[d][i]-latentu_diter);
				}
				part5 += prod*sims[i][j];
			}
		}
	}
	part5 *= beta;


	part4 = 0;
	for (int i = 0;i<ITEM_NUM;i++)
	{
		for (int d = 0;d<DIM;d++)
		{
			part4 += latentV[d][i]*latentV[d][i];
		}
	}
	part4 *= alpha;

	double value = 0.5*(part1+part4+part5+part6);
	//printf("The OBJECTIVE value is %f\n", value);
	cout<< "The OBJECTIVE value is "<<value<<endl;
	return value;
}



double compute_norm_objective(float alpha, float beta, float step, int DIM)
{
	// compute the value of objective function
	float part1=0,part4=0,part5=0,part6=0;
	part1 = 0;
	for (int i = 0;i<RATING_NUM;i++)
	{
		float temp = 0;
		float prod = 0;
		for (int d = 0; d<DIM;d++)
		{
			prod += latentU[d][uids[i]]*latentV[d][mids[i]];
		}
		temp = rates[i]-prod;
		part1 += temp*temp;
	}


	part6 = 0;
	for (int i = 0;i<USER_NUM;i++)
	{
		for (int d = 0;d<DIM;d++)
			part6 += latentU[d][i]*latentU[d][i];
	}
	part6 *= alpha;

	part5 = 0;
	for (int i = 0; i< USER_NUM; i++)
	{
		for (int j = 0; j < USER_NUM; j++)
		{

			float prod = 0;
			float latentu_diter = 0;
			if (sims[i][j] > 0)
			{
				for (int d = 0;d<DIM;d++)
				{
					latentu_diter = latentU[d][j];
					prod+=(latentU[d][i]-latentu_diter)*(latentU[d][i]-latentu_diter);
				}
				part5 += prod*sims[i][j]/sqrt(simvector[i]*simvector[j]);
			}
		}
	}
	part5 *= beta;


	part4 = 0;
	for (int i = 0;i<ITEM_NUM;i++)
	{
		for (int d = 0;d<DIM;d++)
		{
			part4 += latentV[d][i]*latentV[d][i];
		}
	}
	part4 *= alpha;

	double value = 0.5*(part1+part4+part5+part6);
	//printf("The OBJECTIVE value is %f\n", value);
	cout<< "The OBJECTIVE value is "<<value<<endl;
	return value;
}



int learn_parameters_normU(float alpha, float beta, float step, int DIM)
{
		// learn U
		float** old_latentU = new float*[DIM];
		for (int i = 0;i<DIM;i++)
		{
			old_latentU[i] = new float[USER_NUM];
			for (int j = 0;j < USER_NUM;j++)
			{
				old_latentU[i][j]=latentU[i][j];
			}
		}

		float* latentx = new float[USER_NUM];
		memset(latentx,0,sizeof(float)*USER_NUM);
		float* latentw = new float[USER_NUM];
		memset(latentw,0,sizeof(float)*USER_NUM);
		float* gradientU = new float[USER_NUM];
		memset(gradientU,0,sizeof(float)*USER_NUM);


		for (int d = 0; d<DIM;d++)
		{
			for (int i = 0; i<USER_NUM;i++)
			{
				float prod = 0;
				float temp = 0;
				if (userRateVectors[i].size()<1)
				{
					latentx[i] = 0;
					latentw[i] = 0;
				}
				else
				{
					temp = 0;
					prod = 0;
					//for ( int l = userInds[i]; uids[l]==i ;l++)
					for (vector<int>::iterator iter = userRateVectors[i].begin();iter != userRateVectors[i].end();iter++)
					{

						prod += latentV[d][mids[*iter]]*latentV[d][mids[*iter]];
						temp += latentV[d][mids[*iter]]*(rates[*iter]+old_latentU[d][i]*latentV[d][mids[*iter]]);
						float tp = 0;
						for (int m = 0; m <DIM; m++)
							tp += old_latentU[m][i]*latentV[m][mids[*iter]];
						temp -= latentV[d][mids[*iter]]*tp;
					} // iter
					latentx[i] = temp;
					latentw[i] = prod;
				}
				temp = 0;
				float sumsim = 0;
				float lapprod = 0;
				if (beta > 0)
				{
					for (int z = 0; z < USER_NUM; z++)
					{
						if (sims[i][z] > 0)
						{
							lapprod += -sims[i][z]*old_latentU[d][z]*beta/sqrt(simvector[i]*simvector[z]);
							//sumsim += sims[i][z];
						}
					}
				}
				gradientU[i] = (latentw[i]+alpha+beta)*old_latentU[d][i]+lapprod-latentx[i] ;
			} // i for computing gradientU

			float delta = step;
			//float prod = 0;
			//for (int i = 0;i < USER_NUM;i++)
			//{
			//	delta += gradientU[i]*gradientU[i];
			//	float temp = 0;
			//	//int sumt = 0;
			//	float lapprod = 0;
			//	for (set<int>::iterator iter = trustSets[i].begin( ); iter != trustSets[i].end( ); iter++ )
			//	{
			//		float nominator = (float)trustSets[i].size()*(float)trustSets[*iter].size();
			//		lapprod += -1*gradientU[*iter]*beta/sqrt(nominator);
			//		//sumt++;
			//	}
			//	temp = (alpha+beta+Gvector[i])*gradientU[i]+lapprod;
			//	prod += temp*gradientU[i];
			//}
			//delta = delta/prod;

			// update latent U
			for (int i = 0;i < USER_NUM;i++)
			{
				latentU[d][i] = old_latentU[d][i] - delta*gradientU[i];
				//latentU[d][i] = old_latentU[d][i];
				//latentU[d][i] = 0.1;
			} // i

		} // d

		delete [] latentx;
		delete [] latentw;
		delete [] gradientU;

		for (int i = 0;i<DIM;i++)
		{
			delete [] old_latentU[i];
		}
		delete [] old_latentU;
		return 1;

} // learn_parameters_normU()

int learn_parameters_normV(float alpha, float beta, float step, int DIM)
{
	// actually the same as learn_parameters_V()

		float** old_latentV = new float*[DIM];
		for (int i = 0;i<DIM;i++)
		{
			old_latentV[i] = new float[ITEM_NUM];
			for (int j = 0;j < ITEM_NUM;j++)
			{
				//latentV[i][j]=1*(float)rand()/(float)RAND_MAX;
				old_latentV[i][j]=latentV[i][j];
			}
		}

		float* gradientV = new float[DIM];
		memset(gradientV,0,sizeof(float)*DIM);
		for (int j = 0;j<ITEM_NUM;j++)
		{
			for (int d = 0; d<DIM;d++)
			{
				gradientV[d] = 0;
			}
			for (int d = 0;d<DIM;d++)
			{
				float tp1 = alpha*old_latentV[d][j];
				float tp2 = 0;
				float tp3 = 0;
				for (vector<int>::iterator iter = itemRateVectors[j].begin();iter != itemRateVectors[j].end();iter++)
				{
					for (int m = 0; m < DIM;m++)
					{
						tp2 += latentU[m][uids[*iter]]*old_latentV[m][j]*latentU[d][uids[*iter]];
					}
					tp3 += (rates[*iter])*latentU[d][uids[*iter]];
				}
				gradientV[d] = -tp1-tp2+tp3;
			} // d for computing gradientV

			float delta = step;
			//for (int d = 0;d<DIM;d++)
			//{
			//	delta += gradientV[d]*gradientV[d];
			//}
			//float prod = 0;
			//for (vector<int>::iterator iter = itemRateVectors[j].begin();iter != itemRateVectors[j].end();iter++)
			//{
			//	float temp = 0;
			//	for (int m = 0; m < DIM;m++)
			//	{
			//		temp += latentU[m][uids[*iter]]*gradientV[m];
			//	}
			//	prod += temp*temp;
			//}
			////cout<<alpha*delta + prod<<endl;
			//if (delta < (float)1e-8)
			//{
			//	delta = 0;
			//}
			//else
			//{
			//	delta = delta/(alpha*delta + prod);
			//}
			// update latent V
			for (int d = 0;d<DIM;d++)
			{
				latentV[d][j] = old_latentV[d][j] + delta*gradientV[d];
				//latentV[j][i] = old_latentV[j][i];
				//latentV[j][i] = 0.1;
			}
		}

		for (int d = 0;d<DIM;d++)
		{
			delete [] old_latentV[d];
		}
		delete [] old_latentV;

		return 1;

} // learn_parameters_normV()



int learn_parameters_U(float alpha, float beta, float step, int DIM)
{
		// learn U
		float** old_latentU = new float*[DIM];
		for (int i = 0;i<DIM;i++)
		{
			old_latentU[i] = new float[USER_NUM];
			for (int j = 0;j < USER_NUM;j++)
			{
				old_latentU[i][j]=latentU[i][j];
			}
		}

		float* latentx = new float[USER_NUM];
		memset(latentx,0,sizeof(float)*USER_NUM);
		float* latentw = new float[USER_NUM];
		memset(latentw,0,sizeof(float)*USER_NUM);
		float* gradientU = new float[USER_NUM];
		memset(gradientU,0,sizeof(float)*USER_NUM);

		for (int d = 0; d<DIM;d++)
		{
			for (int i = 0; i<USER_NUM;i++)
			{
				float prod = 0;
				float temp = 0;
				if (userRateVectors[i].size()<1)
				{
					latentx[i] = 0;
					latentw[i] = 0;
				}
				else
				{
					temp = 0;
					prod = 0;
					//for ( int l = userInds[i]; uids[l]==i ;l++)
					for (vector<int>::iterator iter = userRateVectors[i].begin();iter != userRateVectors[i].end();iter++)
					{

						prod += latentV[d][mids[*iter]]*latentV[d][mids[*iter]];
						temp += latentV[d][mids[*iter]]*(rates[*iter]+old_latentU[d][i]*latentV[d][mids[*iter]]);
						float tp = 0;
						for (int m = 0; m <DIM; m++)
							tp += old_latentU[m][i]*latentV[m][mids[*iter]];
						temp -= latentV[d][mids[*iter]]*tp;
					} // iter
					latentx[i] = temp;
					latentw[i] = prod;
				}
				temp = 0;
				float sumsim = 0;
				float lapprod = 0;
				if (beta > 0)
				{
					for (int z = 0; z < USER_NUM; z++)
					{
						if (sims[i][z] > 0)
						{
							lapprod += -sims[i][z]*old_latentU[d][z]*beta;
							sumsim += sims[i][z];
						}
					}
				}
				gradientU[i] = (latentw[i]+alpha+beta*sumsim)*old_latentU[d][i]+lapprod-latentx[i] ;
			} // i for computing gradientU

			float delta = step;
			//float prod = 0;
			//for (int i = 0;i < USER_NUM;i++)
			//{
			//	delta += gradientU[i]*gradientU[i];
			//	float temp = 0;
			//	//int sumt = 0;
			//	float lapprod = 0;
			//	for (set<int>::iterator iter = trustSets[i].begin( ); iter != trustSets[i].end( ); iter++ )
			//	{
			//		float nominator = (float)trustSets[i].size()*(float)trustSets[*iter].size();
			//		lapprod += -1*gradientU[*iter]*beta/sqrt(nominator);
			//		//sumt++;
			//	}
			//	temp = (alpha+beta+Gvector[i])*gradientU[i]+lapprod;
			//	prod += temp*gradientU[i];
			//}
			//delta = delta/prod;

			// update latent U
			for (int i = 0;i < USER_NUM;i++)
			{
				latentU[d][i] = old_latentU[d][i] - delta*gradientU[i];
				//latentU[d][i] = old_latentU[d][i];
				//latentU[d][i] = 0.1;
			} // i

		} // d

		delete [] latentx;
		delete [] latentw;
		delete [] gradientU;

		for (int i = 0;i<DIM;i++)
		{
			delete [] old_latentU[i];
		}
		delete [] old_latentU;
		return 1;

} // learn_parameters_U()

int learn_parameters_V(float alpha, float beta, float step, int DIM)
{

		float** old_latentV = new float*[DIM];
		for (int i = 0;i<DIM;i++)
		{
			old_latentV[i] = new float[ITEM_NUM];
			for (int j = 0;j < ITEM_NUM;j++)
			{
				//latentV[i][j]=1*(float)rand()/(float)RAND_MAX;
				old_latentV[i][j]=latentV[i][j];
			}
		}

		float* gradientV = new float[DIM];
		memset(gradientV,0,sizeof(float)*DIM);
		for (int j = 0;j<ITEM_NUM;j++)
		{
			for (int d = 0; d<DIM;d++)
			{
				gradientV[d] = 0;
			}
			for (int d = 0;d<DIM;d++)
			{
				float tp1 = alpha*old_latentV[d][j];
				float tp2 = 0;
				float tp3 = 0;
				for (vector<int>::iterator iter = itemRateVectors[j].begin();iter != itemRateVectors[j].end();iter++)
				{
					for (int m = 0; m < DIM;m++)
					{
						tp2 += latentU[m][uids[*iter]]*old_latentV[m][j]*latentU[d][uids[*iter]];
					}
					tp3 += (rates[*iter])*latentU[d][uids[*iter]];
				}
				gradientV[d] = -tp1-tp2+tp3;
			} // d for computing gradientV

			float delta = step;
			//for (int d = 0;d<DIM;d++)
			//{
			//	delta += gradientV[d]*gradientV[d];
			//}
			//float prod = 0;
			//for (vector<int>::iterator iter = itemRateVectors[j].begin();iter != itemRateVectors[j].end();iter++)
			//{
			//	float temp = 0;
			//	for (int m = 0; m < DIM;m++)
			//	{
			//		temp += latentU[m][uids[*iter]]*gradientV[m];
			//	}
			//	prod += temp*temp;
			//}
			////cout<<alpha*delta + prod<<endl;
			//if (delta < (float)1e-8)
			//{
			//	delta = 0;
			//}
			//else
			//{
			//	delta = delta/(alpha*delta + prod);
			//}
			// update latent V
			for (int d = 0;d<DIM;d++)
			{
				latentV[d][j] = old_latentV[d][j] + delta*gradientV[d];
				//latentV[j][i] = old_latentV[j][i];
				//latentV[j][i] = 0.1;
			}
		}

		for (int d = 0;d<DIM;d++)
		{
			delete [] old_latentV[d];
		}
		delete [] old_latentV;

		return 1;

} // learn_parameters_V()




int free_memory(int DIM, float beta)
{
	//for (int k = 0; k<ITEM_NUM;k++)
	//	itemRateVectors[k].~vector<int>();
	//for (int k = 0; k<USER_NUM;k++)
	//	userRateVectors[k].~vector<int>();
	for (int k = 0; k<USER_NUM;k++)
	{
		delete [] sims[k];
	}
	delete [] sims;
	if (beta > 0)
	{
		delete [] simvector;
	}

	delete [] uids;
	delete [] mids;
	delete [] rates;
	delete [] itemRateVectors;
	delete [] userRateVectors;
	return 1;
}
double compute_errors(const char* testfile, int DIM)
{
	ifstream fin_rate(testfile); 
	int rate_number = 0;
	char buffer_rate[30];
	memset(buffer_rate, 0, 30);
	fin_rate.getline(buffer_rate, 30);
	double mae = 0;
	double* maegrps = new double[8];
	memset(maegrps,0,sizeof(double)*8);
	int* nusergrps = new int[8];
	memset(nusergrps,0,sizeof(int)*8);
	for (int i = 0;i<8;i++)
	{
		maegrps[i]=0;
		nusergrps[i]=0;
	}
	while (strlen(buffer_rate) > 0)
	{
		float input_rate;
		int mid;
		int uid;
		sscanf(buffer_rate, "%d %d %f", &uid, &mid, &input_rate);
		//cout<<latenta[uid]<<"\t"<<latentb[mid]<<"\t"<<endl;

		float prod = 0;
		for (int d = 0; d<DIM;d++)
		{
			prod += latentU[d][uid-1]*latentV[d][mid-1];
			//cout<<latentU[i][uid]<<"\t"<<latentV[i][mid]<<"\t"<<endl;
		}
		float predict = prod + globalmean;
		if (static_cast<int>(userRateVectors[uid-1].size())==0)
		{
			maegrps[0] += fabs(predict - static_cast<float>(input_rate));
			nusergrps[0]++;
		}
		else if (static_cast<int>(userRateVectors[uid-1].size())<=10)
		{
			maegrps[1] += fabs(predict - static_cast<float>(input_rate));
			nusergrps[1]++;
		}
		else if (static_cast<int>(userRateVectors[uid-1].size())<=20)
		{
			maegrps[2] += fabs(predict - static_cast<float>(input_rate));
			nusergrps[2]++;
		}
		else if (static_cast<int>(userRateVectors[uid-1].size())<=40)
		{
			maegrps[3] += fabs(predict - static_cast<float>(input_rate));
			nusergrps[3]++;
		}
		else if (static_cast<int>(userRateVectors[uid-1].size())<=80)
		{
			maegrps[4] += fabs(predict - static_cast<float>(input_rate));
			nusergrps[4]++;
		}
		else if (static_cast<int>(userRateVectors[uid-1].size())<=160)
		{
			maegrps[5] += fabs(predict - static_cast<float>(input_rate));
			nusergrps[5]++;
		}
		else if (static_cast<int>(userRateVectors[uid-1].size())<=320)
		{
			maegrps[6] += fabs(predict - static_cast<float>(input_rate));
			nusergrps[6]++;
		}
		else
		{
			maegrps[7] += fabs(predict - static_cast<float>(input_rate));
			nusergrps[7]++;
		}
		
		
		mae += fabs(predict - static_cast<float>(input_rate));
		memset(buffer_rate, 0, 30);
		fin_rate.getline(buffer_rate, 30);
		rate_number++;
		//cout<<mae<<endl;
	}
	//cout<<mae<<endl;
	fin_rate.close();
	mae = mae/(float)rate_number;
	for (int i=0;i<8;i++)
	{		
		if (nusergrps[i]>0)
		{
			maegrps[i] = maegrps[i]/(float)nusergrps[i];
		}
		printf("The MAE of group %d is %f\n", i, maegrps[i]);
		//cout<<"user number: "<<nusergrps[i]<<endl;
	}
	//printf("Total number of test: %d\n",rate_number);
	printf("The MAE is %f\n",mae);
	return mae;
}


int main(int argc, char **argv)
{
	char* trainfile = argv[1];
	char* testfile = argv[2];
	char* trustfile = argv[3];

	int DIM = atoi(argv[4]);
	float alpha = atof(argv[5]);
	float beta = atof(argv[6]);
	float step = atof(argv[7]);

	preload_data(trainfile,trustfile,beta);
	cout<<"Preloading finished."<<endl;

	printf(" alpha: %f\n beta: %f\n step: %f\n", alpha, beta, step);

	cout<<"Iteration 0: "<<endl;
	InitializeParameter(DIM);
	double minerror = 0;
	double minobj = 0;
	double lasterror = 0;
	double lastobj = 0;

	minobj = compute_norm_objective(alpha, beta, step, DIM);

	lastobj = minobj;
	minerror = compute_errors(testfile, DIM);
	lasterror = minerror;

	printf("Current min error is %f\nCurrent min obj is %f\n", minerror, minobj);

	for (int iter = 1;iter< 1000;iter++)
	{
		cout<<"Iteration "<<iter<<": "<<endl;

		learn_parameters_normU(alpha, beta, step, DIM);
		learn_parameters_normV(alpha, beta, step, DIM);

		double cerror = 0;
		double cobj = 0;

		cobj = compute_norm_objective(alpha, beta, step, DIM);
		cerror = compute_errors(testfile, DIM);

		// update min MAE
		if (cerror <minerror)
			minerror = cerror;

		// update min objective
		if (cobj<minobj)
			minobj = cobj;

		//// show MAE change
		//if (cerror>lasterror)
		//	printf("MAE UP!\n");
		//else if (cerror == lasterror)
		//	printf("MAE STALE\n");
		//else
		//	printf("MAE DOWN!\n");
		//lastobj = cobj;

		//// show objective change
		//if (cobj>lastobj)
		//	printf("OBJTIVE UP!\n");
		//else if (cobj == lastobj)
		//	printf("OBJTIVE STALE\n");
		//else
		//	printf("OBJTIVE DOWN!\n");
		//lasterror = cerror;

		// show current min MAE&objective
		printf("Current error is %f\nCurrent obj is %f\n", cerror, cobj);
		printf("Current min error is %f\nCurrent min obj is %f\n", minerror, minobj);
	}
	cout<<"train finished."<<endl;
	printf("Final min error is %f\nFinal min obj is %f\n", minerror, minobj);
	free_memory(DIM,beta);
	return 1;
}


